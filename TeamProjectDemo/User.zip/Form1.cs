﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace TeamProjectDemo
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
            Init();
            View();
        }
        private void Init()
        {

        }
        private void View()
        {
            this.p2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.p2)).BeginInit();
            this.SuspendLayout();
            // 
            //  p2 동적생성
            // 
            this.p2.Image = global::TeamProjectDemo.Properties.Resources.soju;
            this.p2.Location = new System.Drawing.Point(300, 200);
            this.p2.Name = "p2";
            this.p2.Size = new System.Drawing.Size(100, 100);
            this.p2.TabIndex = 0;
            this.p2.TabStop = false;

            this.Controls.Add(this.p2);

            

            // user객체 생성 , 위치 및 크기 설정 
            sy = new User(pictureBox1, 100, 200);

            sy.SetLocation(sy.X, sy.Y);
            sy.SetSize(118, 106);
          



            //아이템 패스시 사라지는 코드 
           foreach (Item temp in itemList)
            {
                if(temp.picture.Location.X==0)
                {
                    itemList.Remove(temp);
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
                  
            
        }


        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up)
            {
                sy.Jump();
            }
        }
    }
}
