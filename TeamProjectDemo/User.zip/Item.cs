﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Threading;


namespace TeamProjectDemo
{
    class Item : Sprite
    {
        enum Items
        {
            Hotsix, Jokbo, Soju
        }
        protected int plusHp;
        Items itemName;

        public Item(System.Windows.Forms.PictureBox picture, int x, int y) : base(picture, x, y)
        {
            this.plusHp = 0;
            this.x = 600;
            this.y = 200;

            Random random = new Random();
            int choice;

            choice = (int)(random.NextDouble() * 3) + 1;
            if (choice == 1)
            {

                System.Windows.Forms.PictureBox hot;
                hot = new System.Windows.Forms.PictureBox();
                hot.Load(@"C:\Users\hdycg\Desktop\energy-drink.png");
               // hot.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
                hot.Location = new Point(300, 300);

                this.itemName = Items.Hotsix;
                this.plusHp = 20;
                this.picture =hot;
            }
            else if (choice == 2)
            {
                System.Windows.Forms.PictureBox book;
                book = new System.Windows.Forms.PictureBox();
                book.Load(@"C:\Users\hdycg\Desktop\agenda.png");
                // hot.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
                book.Location = new Point(300, 300);

                this.itemName = Items.Jokbo;

                this.picture = book;
                
            }
            else if (choice == 3)
            {
                System.Windows.Forms.PictureBox so;
                so = new System.Windows.Forms.PictureBox();
                so.Load(@"C:\Users\hdycg\Desktop\soju.jpg");
                // hot.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
                so.Location = new Point(300, 300);
                this.itemName = Items.Soju;
                this.picture = so;
            }           
           
        }//생성자

        public void Passing()
        {
            dx = -10;

            while (picture.Location.X >=0)
            {
                move();
                Thread.Sleep(1);
            }

           
        }//Passing()
    }
}
